var path = require('path');

module.exports = {
  tags: ['sanity', 'search'],

  before: function(client) {
    require('nightwatch-pages')(client, path.resolve(__dirname, '..', 'pages'));
  },

  'Upload new post': function (client) {
    client
      .page.homepage.load()
      .page.homepage.newPost()
      .end();
  }
};
