var path = require('path');

module.exports = {
  tags: ['sanity', 'search'],

  before: function(client) {
    require('nightwatch-pages')(client, path.resolve(__dirname, '..', 'pages'));
  },

  'search from homepage': function (client) {
    var searchTerm = 'friend';

    client
      .page.homepage.load()
      .page.homepage.search(searchTerm)
      .page.search_results.assertResults(searchTerm)
      .page.search_results.navImages()
      .end();
  }
};
