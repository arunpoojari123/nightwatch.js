module.exports = {
  selectors: {
    'navImages': '.image-list-link img:nth-child(1)'
  },

  assertResults: function (searchText) {
    return this.client.getAttribute('.cards .post:nth-child(1) .matched-search-term','innerText', function(result) {
     console.log(result.value)
      this.assert.equal(result.value, searchText);
    });
  },

  navImages: function () {
    return this.client.click(this.selectors.navImages);
  }
};
