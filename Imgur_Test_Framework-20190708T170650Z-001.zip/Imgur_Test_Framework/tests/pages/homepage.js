module.exports = {
  
  load: function () {
    return this.client
      .url('https://imgur.com/')
      .waitForElementVisible('body', 1000)
      .assert.title('Imgur: The magic of the Internet');
  },

  search: function (query) {
    return this.client
      .assert.visible('.Searchbar-textInput')
      .setValue('.Searchbar-textInput', query)
      .waitForElementVisible('.Searchbar-submitInput', 1000)
      .click('.Searchbar-submitInput')
      .pause(1000);
  },

  newPost: function(imgPath){
    return this.client
    .waitForElementVisible('.Button.upload',2000)
    .click('.Button.upload')
    .waitForElementVisible('.Dialog.UploadDialog',6000)
    .setValue('input#file-input', require('path').resolve(__dirname + '/download.png'))
    .waitForElementVisible('.Toast-message--check',6000)
    .assert.containsText('.Toast-message--check', 'Upload Complete!')

  }

};

